package driver;

import board.*;

public class GraphicalGame{
	private Player p1, p2;

	public void start(){}
}