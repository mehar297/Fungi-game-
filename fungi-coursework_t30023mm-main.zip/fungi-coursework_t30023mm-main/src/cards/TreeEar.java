package cards;

public class TreeEar extends Mushroom{

	public TreeEar(CardType c){
		super(c, "treeear");
		sticksPerMushroom = 2;
		flavourPoints = 1;
	}
}