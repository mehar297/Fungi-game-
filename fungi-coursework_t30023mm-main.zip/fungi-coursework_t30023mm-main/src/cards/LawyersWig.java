package cards;

public class LawyersWig extends Mushroom{

	public LawyersWig(CardType c){
		super(c, "lawyerswig");
		sticksPerMushroom = 1;
		flavourPoints = 2;
	}
}