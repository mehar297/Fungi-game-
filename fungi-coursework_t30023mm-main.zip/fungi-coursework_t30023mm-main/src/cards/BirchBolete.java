package cards;

public class BirchBolete extends Mushroom{

	public BirchBolete(CardType c){
		super(c, "birchbolete");
		flavourPoints = 3;
		sticksPerMushroom = 2;
	}
}