package cards;

public class Shiitake extends Mushroom{

	public Shiitake(CardType c){
		super(c, "shiitake");
		sticksPerMushroom = 2;
		flavourPoints = 2;
	}
}