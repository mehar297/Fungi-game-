package cards;

public class Basket extends Card{

	public Basket(){
		super(CardType.BASKET, "basket");
	}
}