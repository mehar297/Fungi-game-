package cards;

public class Cider extends EdibleItem{

	public Cider(){
		super(CardType.CIDER, "cider");
		flavourPoints = 5;
	}
}