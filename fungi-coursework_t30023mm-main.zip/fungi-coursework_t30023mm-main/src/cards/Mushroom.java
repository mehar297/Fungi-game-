package cards;

public abstract class Mushroom extends EdibleItem{
	protected int sticksPerMushroom;

	public Mushroom(CardType c, String s){
		super(c,s);
	}

	public int getSticksPerMushroom(){
		return sticksPerMushroom;
	}
}