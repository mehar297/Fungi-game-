package cards;

public class Porcini extends Mushroom{

	public Porcini(CardType c){
		super(c, "porcini");
		sticksPerMushroom = 3;
		flavourPoints = 3;
	}
}