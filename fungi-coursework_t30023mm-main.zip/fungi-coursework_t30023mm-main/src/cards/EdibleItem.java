package cards;

public abstract class EdibleItem extends Card{
	protected int flavourPoints;

	public EdibleItem(CardType c, String s){
		super(c,s);
	}

	public int getFlavourPoints(){
		return flavourPoints;
	}

}