package cards;

public class Chanterelle extends Mushroom{

	public Chanterelle(CardType c){
		super(c,"chanterelle");
		sticksPerMushroom = 2;
		flavourPoints = 4;
	}
}