package cards;

public abstract class Card{
	protected CardType type;
	protected String cardName;

	public Card(CardType c, String s){
		type = c;
		cardName = s;
	}

	public CardType getType(){
		return type;
	}

	public String getName(){
		return cardName;
	}
}