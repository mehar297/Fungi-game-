package cards;

public class HenOfWoods extends Mushroom{

	public HenOfWoods(CardType c){
		super(c, "henofwoods");
		sticksPerMushroom = 1;
		flavourPoints = 3;
		
	}
}