package cards;

public class Pan extends Card{

	public Pan(){
		super(CardType.PAN, "pan");
	}
}
