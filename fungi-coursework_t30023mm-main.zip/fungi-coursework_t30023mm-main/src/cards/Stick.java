package cards;

public class Stick extends Card{

	public Stick(){
		super(CardType.STICK, "stick");
	}
}