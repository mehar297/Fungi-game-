package cards;

public class Butter extends EdibleItem{

	public Butter(){
		super(CardType.BUTTER, "butter");
		flavourPoints = 3;
	}
}