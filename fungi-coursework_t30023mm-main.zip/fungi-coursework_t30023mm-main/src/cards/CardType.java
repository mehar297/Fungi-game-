package cards;

public enum CardType {

	NIGHTMUSHROOM, DAYMUSHROOM, CIDER, BUTTER, PAN, BASKET, STICK ;
}