package cards;

public class HoneyFungus extends Mushroom{

	public HoneyFungus(CardType c){
		super(c, "honeyfungus");
		sticksPerMushroom = 1;
		flavourPoints = 1;
	}
}