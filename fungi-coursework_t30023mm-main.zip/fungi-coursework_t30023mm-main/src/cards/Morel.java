package cards;

public class Morel extends Mushroom{

	public Morel(CardType c){
		super(c, "morel");
		flavourPoints = 6;
		sticksPerMushroom = 4;
	}
}