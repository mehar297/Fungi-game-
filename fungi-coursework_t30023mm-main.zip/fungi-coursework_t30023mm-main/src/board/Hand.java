package board;

import java.util.ArrayList;
import cards.*;

public class Hand implements Displayable{
	private ArrayList<Card> handList = new ArrayList<Card>();

    @Override
	public void add(Card c){
		handList.add(c);
	}

    @Override
	public int size(){
		return handList.size();
	}

	@Override
	public Card getElementAt(int i){
		//int index = i-1;
		return handList.get(i);
	}

    @Override
	public Card removeElement(int i){
		//int index = i-1;
		Card c = handList.get(i);
		handList.remove(i);
		return c;
	}
}