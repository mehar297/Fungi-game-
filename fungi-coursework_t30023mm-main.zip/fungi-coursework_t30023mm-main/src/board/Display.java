package board;

import java.util.ArrayList;
import cards.*;

public class Display implements Displayable{
	private ArrayList<Card> displayList = new ArrayList<Card>();


    @Override
	public void add(Card c){
		displayList.add(c);
	}

    @Override
	public int size(){
		return displayList.size();
	}


    @Override
	public Card getElementAt(int i){
		return displayList.get(i);
	}

    @Override
	public Card removeElement(int i){
		Card c = displayList.get(i);
		displayList.remove(i);
		return c;
	}
}