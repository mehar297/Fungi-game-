package board;

import java.util.ArrayList;
import cards.*;

public class Board{
	private static CardPile forestCardsPile;
	private static CardList forest;
	private static ArrayList<Card> decayPile;

	public static void initialisePiles(){
		forestCardsPile = new CardPile();
		forest = new CardList();
		decayPile = new ArrayList<Card>();
	}

	public static void setUpCards(){

		//daymushrooms

		HoneyFungus honeyfungusD = new HoneyFungus(CardType.DAYMUSHROOM);
        TreeEar treeearD = new TreeEar(CardType.DAYMUSHROOM);
        LawyersWig lawyerswigD = new LawyersWig(CardType.DAYMUSHROOM);
        Shiitake shiitakeD = new Shiitake(CardType.DAYMUSHROOM);
        HenOfWoods henofwoodsD = new HenOfWoods(CardType.DAYMUSHROOM);
        BirchBolete birchboleteD = new BirchBolete(CardType.DAYMUSHROOM);
        Porcini porciniD = new Porcini(CardType.DAYMUSHROOM);
        Chanterelle chanterelleD = new Chanterelle(CardType.DAYMUSHROOM);
        Morel morelD = new Morel(CardType.DAYMUSHROOM);

        //nightmushrooms

        HoneyFungus honeyfungusN = new HoneyFungus(CardType.NIGHTMUSHROOM);
        TreeEar treearN = new TreeEar(CardType.NIGHTMUSHROOM);
        LawyersWig lawyerswigN = new LawyersWig(CardType.NIGHTMUSHROOM);
        Shiitake shiitakeN = new Shiitake(CardType.NIGHTMUSHROOM);
        HenOfWoods henofwoodsN = new HenOfWoods(CardType.NIGHTMUSHROOM);
        BirchBolete birchboleteN = new BirchBolete(CardType.NIGHTMUSHROOM);
        Porcini porciniN = new Porcini(CardType.NIGHTMUSHROOM);
        Chanterelle chanterelleN = new Chanterelle(CardType.NIGHTMUSHROOM);

        //others

        Pan pan_ = new Pan();
        Cider cider_ = new Cider();
        Butter butter_ = new Butter();
        Basket basket_ = new Basket();
        Stick stick_ = new Stick();

        //adding 79 cards to forest card pile
        for (int i=1; i<=10; i++){
        	forestCardsPile.addCard(honeyfungusD);
        }

        for (int i=1; i<=8; i++){
        	forestCardsPile.addCard(treeearD);
        }

        for (int i=1; i<=6; i++){
        	forestCardsPile.addCard(lawyerswigD);
        }

        for (int i=1; i<=5; i++){
        	forestCardsPile.addCard(shiitakeD);
        	forestCardsPile.addCard(henofwoodsD);
        }

        for (int i=1; i<=4; i++){
        	forestCardsPile.addCard(birchboleteD);
        	forestCardsPile.addCard(porciniD);
        	forestCardsPile.addCard(chanterelleD);
        }

        for (int i=1; i<=3; i++){
        	forestCardsPile.addCard(morelD);
        }

        forestCardsPile.addCard(honeyfungusN);
        forestCardsPile.addCard(treearN);
        forestCardsPile.addCard(lawyerswigN);
        forestCardsPile.addCard(shiitakeN);
        forestCardsPile.addCard(henofwoodsN);
        forestCardsPile.addCard(birchboleteN);
        forestCardsPile.addCard(porciniN);
        forestCardsPile.addCard(chanterelleN);

        for (int i=1; i<=3; i++){
        	forestCardsPile.addCard(butter_);
        }

        for (int i=1; i<=3; i++){
        	forestCardsPile.addCard(cider_);
        }

        for (int i=1; i<=11; i++){
        	forestCardsPile.addCard(pan_);
        }

        for (int i=1; i<=5; i++){
        	forestCardsPile.addCard(basket_);
        }
	}

	public static CardPile getForestCardsPile(){
		return forestCardsPile;
	}

	public static CardList getForest(){
		return forest;
	}

	public static ArrayList<Card> getDecayPile(){
		return decayPile;
	}

	public static void updateDecayPile(){
        // clear decay pile if size is 4
        if (decayPile.size() == 4)
            decayPile = new ArrayList<Card>();
        decayPile.add(forest.removeCardAt(1));
	}
			

}