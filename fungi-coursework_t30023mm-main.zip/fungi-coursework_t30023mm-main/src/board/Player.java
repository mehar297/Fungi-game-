package board;

import java.util.ArrayList;
import cards.*;

public class Player{
	private Hand h;
	private Display d;
	private int score;
	private int handlimit;
	private int sticks;

	public Player()
	{
		h = new Hand();
		d = new Display();
		d.add(new Pan());
		score = 0;
		handlimit = 8;
		sticks = 0;
	}

	public int getScore(){
		return score;
	}

	public int getHandLimit(){
		return handlimit;
	}

	public int getStickNumber(){
		return sticks;
	}

	public void addSticks(int n)
	{
		sticks += n;
	    Stick stick;
		for (int j=0; j<n; j++)
		{
			stick = new Stick();
			d.add(stick);
	    }
	}

	public void removeSticks(int n)
	{
		sticks -= n;
		for (int j=0; (j< d.size() && n>0);){
				if (d.getElementAt(j).getType() == CardType.STICK){
					d.removeElement(j);
					n-=1;
				}
				else
					j++;
		}	
	}

	public Hand getHand(){
		return h;
	}

	public Display getDisplay(){
		return d;
	}

	public void addCardtoHand(Card c)
	{
		if(c.getType() != CardType.BASKET  &&  c.getType() != CardType.STICK)
			h.add(c);
		else 
			addCardtoDisplay(c);
	}

	public void addCardtoDisplay(Card c)
	{
		d.add(c);
		if (c.getType() == CardType.BASKET){
			handlimit += 2;
		}
		else if (c.getType() == CardType.STICK){
			sticks++;
		}
	}

	public boolean takeCardFromTheForest(int i)
	{

		if ((handlimit - (h.size())) > 0)
			{
			if (i==1 || i==2){
				Card x = Board.getForest().removeCardAt(i);
				if (x.getType() == CardType.BASKET){
					addCardtoDisplay(x);
					return true;
				}
				else
					h.add(x);
					return true;
			}

			else if (i<=8)
			{
				if(sticks >= (i-2)){
					Card x = Board.getForest().removeCardAt(i);
					if (x.getType() == CardType.BASKET){
						addCardtoDisplay(x);
						removeSticks(i-2);
				
					}
					else{
						h.add(x);
						removeSticks(i-2);
				
					}
					return true;

				}
				else
					return false;
			}
			else
				return false;

		}
		else 
			return false;
	}

	public boolean takeFromDecay()
	{
		int basketsindecay = 0;
		for (int i=0; i<Board.getDecayPile().size(); i++)
		{
			if (Board.getDecayPile().get(i).getType() == CardType.BASKET){
				basketsindecay++;
			}
		}
		if ((Board.getDecayPile().size() - basketsindecay) <= ((handlimit - h.size()) + (2 * basketsindecay)))
		{
			for (int i = 0; i < Board.getDecayPile().size();i++)
						{
							Card x = Board.getDecayPile().get(i);
							if (x.getType() == CardType.BASKET)
							{
								addCardtoDisplay(x);
							}
							else
							{
								addCardtoHand(x);
							}
						}
			Board.getDecayPile().clear();
			return true;
		}

		else
			return false;
		
	}

	public boolean cookMushrooms(ArrayList<Card> cookList)
	{
		boolean pan_ = false; 
		int mushroom_ = 0; 
		int butter_ = 0; 
		int cider_ = 0;
		int score_ = 0;
		String mushtype = "";
		boolean sametype = true;
		for (int i=0; i< cookList.size(); i++)
		{
			CardType c = cookList.get(i).getType();
			if (c == CardType.PAN)
			{
		 		pan_ = true;
		 	}
		 	else if (c == CardType.BUTTER)
		 	{
		 		butter_++;
		 		score_ += 3;
		 	}
		 	else if (c == CardType.CIDER)
		 	{
		 		cider_++;
		 		score_+= 5;
		 	}
		 	else if (c == CardType.DAYMUSHROOM || c == CardType.NIGHTMUSHROOM)
		 	{
		 			if (mushtype.isEmpty())
		 			{
		 				mushtype += cookList.get(i).getName();
		 				if (c == CardType.DAYMUSHROOM)
		 				{
		 					mushroom_ ++;
		 					score_ += ((EdibleItem)cookList.get(i)).getFlavourPoints();
		 				}
		 				else
		 				{
		 					mushroom_ += 2;
		 					score_ += 2 * ((EdibleItem)cookList.get(i)).getFlavourPoints();
		 				}

		 			}
		 			else
		 			{
		 				if (cookList.get(i).getName().equals(mushtype))
		 				{
		 					if (c == CardType.DAYMUSHROOM)
		 					{
		 						mushroom_ ++;
		 						score_ += ((EdibleItem)cookList.get(i)).getFlavourPoints();
		 					}
		 					else
		 					{
		 						mushroom_ += 2;
		 						score_ += 2 * ((EdibleItem)cookList.get(i)).getFlavourPoints();
		 					}
		 				}
		 				else
		 				{
		 					sametype = false;
		 					break;
		 				}
		 			}
		 		
		 	}
		 	else
		 		return false;

		}

		for (int i=0; i< this.d.size(); i++)
		{
			if (this.d.getElementAt(i).getType() == CardType.PAN)
			{
				pan_ = true;
			}
		}

		if (pan_ && mushroom_ >= 3 && sametype == true)
		{
			if (mushroom_ >= ((4*butter_) + (5*cider_)))
			{
				this.score += score_;
				for (int i=0; i<cookList.size(); i++)
				{
					for (int j=0; j<this.h.size(); j++)
					{
						if (cookList.get(i) == this.h.getElementAt(j)){
							this.h.removeElement(j);
						}
					}
					for (int k=0; k<this.d.size(); k++)
					{
						if (cookList.get(i) == this.d.getElementAt(k)){
							this.d.removeElement(k);
						}
					}
				}
				return true; 
			}
			else
				return false;
		}

		else
			return false;
		
	}

	public boolean sellMushrooms(String s, int n){
		String a = "";
		for (int i=0; i< s.length(); i++){
			char x = s.charAt(i);
			if (Character.isUpperCase(x))
				a += Character.toLowerCase(x);
			else if (Character.isLowerCase(x))
				a += x;
			else
				a += "";
		}
		
		String mushroom_type = "";
		String[] types = {"birchbolete","chanterelle","henofwoods", "honeyfungus",  "lawyerswig", "morel", "porcini", "shiitake", "treeear"};

		for (int i=0; i<types.length; i++)
		{
			if (a.equals(types[i])){
				mushroom_type += types[i];
			}
		}

		int count_d = 0;
		int count_n = 0;
		int d_stick = 0;
		int n_stick = 0;

		if (!mushroom_type.equals(""))
		{
			for (int i=0; i<this.h.size(); i++){
				if (mushroom_type.equals(this.h.getElementAt(i).getName()))
				{
					if (this.h.getElementAt(i).getType() == CardType.DAYMUSHROOM){
						count_d++;
					}
					else if (this.h.getElementAt(i).getType() == CardType.NIGHTMUSHROOM){
						count_n++;
					}

					if (n_stick == 0){
						d_stick = ((Mushroom)this.h.getElementAt(i)).getSticksPerMushroom();
						n_stick = 2 * ((Mushroom)this.h.getElementAt(i)).getSticksPerMushroom();
					}

				}
			}

			if ((n/2) < count_n){
				count_n = count_n/2;
			}
			if ((n - (2 * count_n) )<= count_d){
				count_d = n - (2*count_n);
			}

			if((n >= 2) && ((count_d) + (2*count_n))==n){
				this.addSticks((count_n * n_stick) + (count_d * d_stick));
				int i=0;
				while (i<this.h.size() && ((count_n + count_d)>0))
				{
					Card c = this.h.getElementAt(i);
					if (c.getName().equals(mushroom_type))
					{
						if ((count_d>0) && c.getType()==CardType.DAYMUSHROOM)
						{
							count_d--;
							this.h.removeElement(i);
						}
						else if ((count_n>0) && c.getType()==CardType.NIGHTMUSHROOM)
						{
							count_n--;
							this.h.removeElement(i);
						}
						else
							i++;
					}
					else
						i++;
				}
				return true;
			}
			else
				return false;

		}
		else
			return false;

	}

	public boolean putPanDown(){
		boolean pan_ = false;
		for (int i=0; i< h.size(); i++){
			if (getHand().getElementAt(i).getType()==CardType.PAN){
				h.removeElement(i);
				d.add(new Pan());
				pan_ = true;
				break;
			}
		}
		if (pan_)
			return true;
		else
			return false;
	}

}