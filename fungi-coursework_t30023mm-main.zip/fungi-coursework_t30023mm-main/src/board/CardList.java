package board;

import java.util.ArrayList;
import cards.*;

public class CardList{
	private ArrayList<Card> cList;


	public CardList(){
		cList = new ArrayList<Card>();
	}

	public void add(Card c){
		ArrayList<Card> new_list = new ArrayList<Card>();
		new_list.add(c);
		for (int i=0; i<size(); i++){
			new_list.add(cList.get(i));
		}
		cList = new_list;  //add all the cards?
	}

	public int size(){
		return cList.size();
	}

	public Card getElementAt(int i){
		return cList.get(i);
	}

	public Card removeCardAt(int i){
		Card c = cList.get(8-i);
		cList.remove(8-i);
		return c;
	}
}

